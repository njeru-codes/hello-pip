# hello_pip

this is a sample pyhton package to test writing python packages and publishing 
to pypi repository

Please do not install this dummy package
## installation
```
    pip install
```

## usage
```python

    from hello_pip import hello_pip

    #call sample function
    hello_pip()
```

